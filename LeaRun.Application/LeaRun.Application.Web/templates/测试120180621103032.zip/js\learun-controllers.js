﻿angular.module('starter.controllers', [])
.controller(page253d41da-9aec-f7b4-2c29-a2e2bc65091a'Ctrl',['$scope',
function ($scope,) {};
}])
;

